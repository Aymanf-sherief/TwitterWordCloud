from setuptools import setup

setup(name='twitter_word_cloud',
      version='0.1',
      description='Gaussian distributions',
      packages=['twitter_word_cloud'],
      zip_safe=False)